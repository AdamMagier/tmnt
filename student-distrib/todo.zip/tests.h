#ifndef TESTS_H
#define TESTS_H

// test launcher
void launch_tests();

#endif /* TESTS_H */
