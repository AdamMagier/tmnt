#include "tests.h"
#include "x86_desc.h"
#include "lib.h"
#include "handlers.h"
#include "keyboard.h"
#include "rtc.h"
#include "rtc_drivers.h"
#include "terminal.h"
#include "paging.h"
#include "process.h"
#include "sys_call.h"

#define PASS 1
#define FAIL 0
#define STANDARD_EXCEPTION_NUM 22
#define TEN_SEC 10
#define TEST_READ_LENGTH 20

#define PARTIAL_BUFFER_SIZE 0x03
#define ARBITRARY_TEXT_LENGTH 231
#define ARG_BUF_LENGTH 1024

#define DELAY 5000000

#define RUN_DELAY do { putc(' '); putc('\b'); } while (0)

// Create ints to point to as a read_rtc parameter.
int _2_HZ = 2;
int _4_HZ = 4;
int  _8_HZ = 8;
int  _16_HZ = 16;
int  _32_HZ = 32;
int  _64_HZ = 64;
int  _128_HZ = 128;
int  _256_HZ = 256;
int  _512_HZ = 512;
int  _1024_HZ = 1024;

/* format these macros as you see fit */
#define TEST_HEADER     \
    printf("[TEST %s] Running %s at %s:%d\n", __FUNCTION__, __FUNCTION__, __FILE__, __LINE__)
#define TEST_OUTPUT(name, result)    \
    printf("[TEST %s] Result = %s\n", name, (result) ? "PASS" : "FAIL");

//declare an iterator
int i;

static inline void assertion_failure(){
    /* Use exception #15 for assertions, otherwise
       reserved by Intel */
    asm volatile("int $15");
}

static inline void test_exceptions(){
    /* function to test arbitrary exceptions; replace number as necessary*/
    asm volatile("int $12");
}
/* Checkpoint 1 tests */

/* IDT Test - Example
 * 
 * Asserts that first 10 IDT entries are not NULL
 * Inputs: None
 * Outputs: PASS/FAIL
 * Side Effects: None
 * Coverage: Load IDT, IDT definition
 * Files: x86_desc.h/S
 */
int idt_test(){
    TEST_HEADER;
    int result = PASS;
    for (i = 0; i < STANDARD_EXCEPTION_NUM; ++i){
        if ((idt[i].offset_15_00 == NULL) && 
            (idt[i].offset_31_16 == NULL)){
            assertion_failure();
            result = FAIL;
        }
    }

    return result;
}

/* IDT Test Offsets
 * 
 * Asserts that standard exceptions' offsets match the address of their handlers.
 * Inputs: None
 * Outputs: PASS/FAIL
 * Side Effects: None
 * Coverage: fill_idt
 * Files: x86_desc.h/S, handlers.c
 */
int idt_test_offsets(){
    TEST_HEADER;

    int result = PASS;
    for (i = 0; i < STANDARD_EXCEPTION_NUM; ++i){
    void (*handler)() = exception_jumptable[i];
        if ((idt[i].offset_15_00 != ((int)handler & 0x0000FFFF)) || 
            (idt[i].offset_31_16 != (((int)handler & 0xFFFF0000)>>16))){
            assertion_failure();
            result = FAIL;
        }
    }

    return result;
}

/* RTC Interrupt Test
 * 
 * Asserts that an interrupt calls the correct handler.
 * Must call this test individually, as the handler will halt execution.
 * Manually examine the output to ensure correctness.
 * Inputs: None
 * Outputs: None
 * Side Effects: Creates an RTC interrupt
 * Coverage: handlers.c, handlers_asm
 */
void rtc_interrupt_test(){
    asm volatile("int $24");
}


/* See test_paging.c for Checkpoint 1 paging tests */

/* Checkpoint 2 tests */

/* RTC Test Read Return
 * 
 * Tests that the rtc read function returns after an interrupt has occured.
 * Inputs: None
 * Outputs: PASS/FAIL
 * Side Effects: None
 * Coverage: system_calls.c
 */
int rtc_test_read_return(){
    //TEST_HEADER;
    int result = PASS;
    // **clarify that it should return after any interrupt, vs any interrupt after it's been called?
    read_rtc(0, 0, 0);
    if (rtc_interrupt_counter <= 0){
        result = FAIL;
    }
    //printf("%d\n", rtc_interrupt_counter);
    return result;
}

/* RTC Test Read Print
 * 
 * Tests setting the RTC at a variety of frequencies.
 * Inputs: None
 * Outputs: None
 * Side Effects: Prints "1" for every interrupt
 * Manually examine to ensure correctness.
 * Coverage: system_calls.c
 */
void rtc_test_read_print(){
    
    reset_screen();
    
    write_rtc(0, &(_2_HZ), 0);
    //run for 10 seconds
    while(rtc_interrupt_counter < _2_HZ * TEN_SEC){
        read_rtc(0, 0, 0);
        printf("1");
    }
    rtc_interrupt_counter = 0;
    
    reset_screen();

    write_rtc(0, &(_4_HZ), 0);
    while(rtc_interrupt_counter < _4_HZ * TEN_SEC){
        read_rtc(0, 0, 0);
        printf("1");
    }
    rtc_interrupt_counter = 0;
    
    reset_screen();

    write_rtc(0, &(_8_HZ), 0);
    while(rtc_interrupt_counter < _8_HZ * TEN_SEC){
        read_rtc(0, 0, 0);
        printf("1");
    }
    rtc_interrupt_counter = 0;
    
    reset_screen();

    write_rtc(0, &(_16_HZ), 0);
    while(rtc_interrupt_counter < _16_HZ * TEN_SEC){
        read_rtc(0, 0, 0);
        printf("1");
    }
    rtc_interrupt_counter = 0;
    
    reset_screen();

    write_rtc(0, &(_32_HZ), 0);
    while(rtc_interrupt_counter < _32_HZ * TEN_SEC){
        read_rtc(0, 0, 0);
        printf("1");
    }
    rtc_interrupt_counter = 0;
    
    reset_screen();

    write_rtc(0, &(_64_HZ), 0);
    while(rtc_interrupt_counter < _64_HZ * TEN_SEC){
        read_rtc(0, 0, 0);
        printf("1");
    }
    rtc_interrupt_counter = 0;
    
    reset_screen();

    write_rtc(0, &(_128_HZ), 0);
    while(rtc_interrupt_counter < _128_HZ * TEN_SEC){
        read_rtc(0, 0, 0);
        printf("1");
    }
    rtc_interrupt_counter = 0;
    
    reset_screen();

    write_rtc(0, &(_256_HZ), 0);
    while(rtc_interrupt_counter < _256_HZ * TEN_SEC){
        read_rtc(0, 0, 0);
        printf("1");
    }
    rtc_interrupt_counter = 0;
    
    reset_screen();

    write_rtc(0, &(_512_HZ), 0);
    while(rtc_interrupt_counter < _512_HZ * TEN_SEC){
        read_rtc(0, 0, 0);
        printf("1");
    }
    rtc_interrupt_counter = 0;
    
    reset_screen();

    write_rtc(0, &(_1024_HZ), 0);
    while(rtc_interrupt_counter < _1024_HZ * TEN_SEC){
        read_rtc(0, 0, 0);
        printf("1");
    }
    rtc_interrupt_counter = 0;
    
    reset_screen();
}

/* Test Paging Pass
 *
 * Check that video memory access and kernel access properly set up. 
 * No exceptions should be generated if paging setup is successful.
 * Inputs: None
 * Outputs: None
 * Side Effects: Will cause an exception if paging incorrectly set up.
 * Coverage: paging.c, paging.h
*/
void test_paging_pass(void)
{
    int* x;
    x = (int*)(0x1000*184);        //video memory
    int y = *x;
    
    x = (int*)(0x400000);                //kernel memory
    y = *x;
    
    x = (int*)(0x1000*185 - 0x100);        //video memory
    y = *x;
    
    
    
}

/* Test Paging Fail
 *
 * Check that areas outside of the kernel and video memory cannot be accesed. 
 * Any one of these test cases should generate a page fault exception,
 * Inputs: None
 * Outputs: None
 * Side Effects: Will cause an exception if paging is correctly set up.
 * Coverage: paging.c, paging.h
*/
void test_paging_fail(void)
{
    int* x;
    int y;
    x = (int*)(0);                        //NULL pointer
    y = *x;
    
    x = (int*)(0xF00000);                //not kernel or video memory
    y = *x;
    
    x = (int*)(0x1000*183);                //near but not in video memory
    y = *x;
    
}


/* Terminal Test
 * 
 * Tests everything (_EVERYTHING_) relating to the terminal
 * Inputs: None
 * Instructions pop up on screen so the test should be pretty self explanatory.
 * Coverage: terminal.c
 */
void terminal_test()
{
    uint8_t num_copied;
    
    /* Buffers for copying the text */
    void * full_buffer[INPUT_BUFFER_SIZE] = {0};
    void * partial_buffer[PARTIAL_BUFFER_SIZE] = {0};
    void * arbitrary_buffer;
    
    /* Arbitrary text to see how we handle larger messages */
    char* arbitrary_text = "Lorem ipsum dolor sit amet, \
consectetur adipiscing elit, sed do eiusmod tempor incididunt \
ut labore et dolore magna aliqua. Ut enim ad minim veniam, \
quis nostrud exercitation ullamco laboris nisi ut aliquip \
ex ea commodo consequat.";
    arbitrary_buffer = (void*) arbitrary_text;
    
    /* Clear before testing */
    reset_screen();
    
    printf("TERMINAL TESTS\n");
    printf("=============\n");
    
    /* Testing invalid params */
    printf("Testing reading to null pointer...");
    if (terminal_read(0, 0, INPUT_BUFFER_SIZE) == -1)
    {
        printf("Null properly handled!\n");
    }
    else
    {
        printf("Null not handled!\n");
        return;
    }
    
    printf("Testing reading invalid number of bytes...");
    if (terminal_read(0, full_buffer, -1))
    {
        printf("Handled properly!\n");
    }
    else
    {
        printf("Not handled!\n");
        return;
    }
    
    printf("Testing writing from null pointer...");
    if (terminal_read(0, 0, INPUT_BUFFER_SIZE) == -1)
    {
        printf("Null properly handled!\n");
    }
    else
    {
        printf("Null not handled!\n");
        return;
    }
    
    printf("Testing writing invalid number of bytes...");
    if (terminal_read(0, full_buffer, -1))
    {
        printf("Handled properly!\n");
    }
    else
    {
        printf("Not handled!\n");
        return;
    }
    
    printf("<Note: Delays are intentional and serve to facilitate grading.>\n");
    
    /* Delay for a bit... */
    { volatile int ii; for (ii = 0; ii < DELAY; ii++) { RUN_DELAY; } }
    
    printf("=============\n");
    
    printf("Testing scrolling...\nG\nI\nV\nE\nG\nO\nO\nD\nG\nR\nA\nD\nE\nP\nL\nE\nA\nS\nE\n");
    printf("Text should've properly scrolled!\n");
    
    /* Delay for a bit... */
    { volatile int ii; for (ii = 0; ii < DELAY; ii++) { RUN_DELAY; } }
    
    printf("=============\n");
    
    /* Actual text/input case */
    printf("Testing actually inputting text...Type something!\n");
    printf("(Feel free to test commands as well!)\n");
    num_copied = terminal_read(0, full_buffer, INPUT_BUFFER_SIZE);
    printf("Number of bytes copied: %d\n\n", num_copied);
    
    printf("Testing writing actual text...\n");
    terminal_write(0, full_buffer, num_copied);
    printf("That should be the message you typed!\n");
    
    /* Delay for a bit... */
    { volatile int ii; for (ii = 0; ii < DELAY; ii++) { RUN_DELAY; } }
    
    printf("=============\n");
    
    /* Getting partial input */
    printf("Testing getting partial input...Type something!\n");
    printf("(Longer than 3 characters!)\n");
    num_copied = terminal_read(0, partial_buffer, PARTIAL_BUFFER_SIZE);
    printf("\nWriting the partial input...\n");
    terminal_write(0, partial_buffer, PARTIAL_BUFFER_SIZE);
    printf("\nThat should be the first three characters of your message!\n");
    
    /* Delay for a bit... */
    { volatile int ii; for (ii = 0; ii < DELAY; ii++) { RUN_DELAY; } }
    
    printf("=============\n");
    
    /* Arbitrary length string */
    printf("Testing writing an arbitrarily long text...\n");
    terminal_write(0, arbitrary_buffer, ARBITRARY_TEXT_LENGTH);
    printf("\n\nThe text should read:\n%s\n", arbitrary_text);
    printf("Make sure that this is the case!\n");
    
}


/* Checkpoint 3 tests */

/* Syscall Open Test
 * 
 * Tests syscall for open
 * Inputs: None
 * Attempts to open a file with an invalid name.
 * Coverage: sys_open (sys_call.c)
 */
void open_test(){

    if (sys_open((uint8_t*)"invalidname") == -1){
        printf("Successfully detected invalid filename\n");
    }
}

/* Syscall Execute Test
 * 
 * Tests sys_execute
 * Inputs: None
 * Attempts to execute a non-executable, and a file with an invalid name
 * Coverage: sys_execute (sys_call.c)
 */
void execute_test(){

    if (sys_execute((uint8_t*)"") == -1){
        printf("Successfully detected invalid filename\n");
    }

    // Try to execute a present but non-executable file
     if (sys_execute((uint8_t*)"frame1.txt") == -1){
        printf("Successfully detected non-executable\n");
    }

}

/* Syscall Close Test
 * 
 * Tests syscall for close
 * Inputs: None
 * Attempts to close both reserved and invalid file descriptors. 
 * Coverage: sys_close (sys_call.c)
 */
void close_test(){
    //Attempt to close a reserved descriptor
     if (sys_close(1) == -1){
        printf("Successfully prevented reserved fd from closure\n");
    }
    //Attempt to close an invalid descriptor
     if (sys_close(FD_ARRAY_SIZE) == -1){
        printf("Successfully prevented invalid fd from closure\n");
    }

}


/* Checkpoint 4 tests */


/* invalid_buf_test 
 * 
 * Tests an invalid buffer case for getargs syscall
 * Inputs: None
 * Attempts to call getargs with a null buffer pointer. 
 * Coverage: sys_getargs (sys_call.c)
 */
void invalid_buf_test(){
    uint8_t * buf = 0;
     if (sys_getargs(buf, ARG_BUF_LENGTH) == -1){
        printf("Successfully detected invalid buffer\n");
    }
}

/* invalid_nbytes_test 
 * 
 * Tests an invalid nbytes value for getargs syscall
 * Inputs: None
 * Attempts to call getargs with a negative nbytes value. 
 * Coverage: sys_getargs (sys_call.c)
 */
void invalid_nbytes_test(){
    uint8_t * testbuf;
     if (sys_getargs(testbuf, -1) == -1){
        printf("Successfully detected invalid nbytes value\n");
    }
}

/* invalid_vidmap_ptr_test 
 * 
 * Tests an invalid pointer case for vidmap syscall
 * Inputs: None
 * Attempts to call vidmap with a screen start pointer outside of user space. 
 * Coverage: sys_vidmap (sys_call.c)
 */
void invalid_vidmap_ptr_test(){
    uint8_t** screen_start = 0;
    if (sys_vidmap(screen_start) == -1){
        printf("Successfully detected invalid vidmap pointer\n");
    }
}

/* Checkpoint 5 tests */


/* Test suite entry point */
void launch_tests(){
    //TEST_OUTPUT("idt_test",idt_test());
    //TEST_OUTPUT("idt_test_offsets",idt_test_offsets());

    //test_exceptions();
    //TEST_OUTPUT("rtc_test_read_return", rtc_test_read_return());
    //blank();
    //if(sys_open((const uint8_t*)"shell")==-1) printf("shell open failed\n");
    //if(sys_execute((const uint8_t*)"shell") ==-1) printf("shell execute failed\n");
    //rtc_test_read_print();
    //terminal_test();
    // open_test();
    // execute_test();
    // close_test();
     //invalid_buf_test();
     //invalid_nbytes_test();
    // invalid_vidmap_ptr_test();
    

}
