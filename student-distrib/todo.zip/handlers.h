
#define GENERIC_EXCEPTIONS 32
#define SYS_CALL 0x80
#define PIT_INTERRUPT 0x20
#define KEYBOARD_INTERRUPT 0x21
#define RTC_INTERRUPT 0x28
#define HARDWARE_EXCEPTIONS 22
#define MOUSE_INTERRUPT 0x2C

extern void fill_idt();
extern void emptyfunc();


typedef void (*handler)();

// 22 Exceptions defined by Intel, plus a generic exception
extern handler exception_jumptable[23];

extern void asm_generic_system_call();
extern void asm_generic_keyboard_interrupt();
extern void asm_generic_exception();
extern void asm_generic_RTC_interrupt();
extern void asm_pit_interrupt();
extern void asm_generic_mouse_interrupt();

void set_bits(idt_desc_t * entry);
