#include "tests.h"
#include "x86_desc.h"
#include "lib.h"
#include "handlers.h"
#include "keyboard.h"
#include "rtc.h"
#include "rtc_drivers.h"
#include "file_drivers.h"
#include "process.h"
#include "sys_call.h"


uint8_t * filesys_img;        
static int directory_read_index = 0;



/*==================FILE HANDLERS============================*/


/*    int32_t open_file(const uint8_t* filename)
    Opens a file described by the given filename
    Inputs: file descriptor of file to open
    Outputs: None
    Return: 0 if the file is found in the filesys, -1 if it is not found
    Side effects: increments the static open_files_counter
*/
int32_t open_file(const uint8_t* filename)
{

    //int file_desc;        //file descriptor associated with the file to be opened


    boot_block_t working_block;
    init_boot_block(&working_block);
    d_entry_t working_dentry;

    if(read_dentry_by_name(filename, &working_dentry) == -1) return -1;        //if an equivalent d_entry was not found, return -1
    return working_dentry.inode_number;
}


/*    int32_t read_file(int32_t fd, void* buf, int32_t nbytes)
    Reads from a given file into a given buffer
    Inputs: file descriptor of file to copy from, buffer to copy to, number of bytes to copy (not used)
    Outputs: None
    Return: number of bytes successfully copied
    Side effects: None
*/
int32_t read_file(int32_t fd, void* buf, int32_t nbytes){


    if(CURRENT_PCB_ADDRESS->fd_array[fd].flags == AVAILABLE) return -1;     //return -1 if the fd index is not allocated
    if(nbytes<0) return -1;    //return an error if the number of bytes to be copied is negative
    boot_block_t working_block;
    init_boot_block(&working_block);
    int32_t bytes_copied;
    uint8_t * working_buffer = (uint8_t*)buf;    //typecast the void pointer
    int32_t length = nbytes;


    int inode_index = CURRENT_PCB_ADDRESS->fd_array[fd].inode;        //find the inode index from the file directory
    uint32_t offset = CURRENT_PCB_ADDRESS->fd_array[fd].position;    //find the current position in the directory from the fd array


    bytes_copied = read_data(inode_index, offset, working_buffer, length);     //read length bytes from the beginning of the file to the buffer
    offset += bytes_copied;

    CURRENT_PCB_ADDRESS->fd_array[fd].position = offset;    //increment the offset into the file
  
    return bytes_copied;
}



/*    int32_t write_file(int32_t fd, const void* buf, int32_t nbytes)
    Writes to a given file. Not implemented in read-only file system
    Inputs: file descriptor of file to write to, buffer to write from, number of bytes to write
    Outputs: None
    Return: -1 on failure
    Side effects: None
*/
int32_t write_file(int32_t fd, const void* buf, int32_t nbytes){
    

    return -1;
}



/*    int32_t close_file(int32_t fd)
    Closes the file associated with the given file descriptor
    Inputs: file descriptor of file to close
    Outputs: None
    Return: 0 on success
    Side effects: decrements the static open_files_counter
*/
int32_t close_file(int32_t fd)
{
    return 0;
}



/*    int32_t read_file_placeholder(const uint8_t* filename, void *buf, int32_t nbytes, uint32_t offset)
    Reads a file described by the given filename into the given buffer
    Inputs: filename to be read from, buffer to copy to, number of bytes to copy, offset in file to begin copy
    Outputs: Corresponding data from file to buffer
    Return: number of bytes successfully copied
    Side effects: None
*/
int32_t read_file_placeholder(const uint8_t* filename, void *buf, int32_t nbytes, uint32_t offset)
{
    boot_block_t working_block;
    init_boot_block(&working_block);
    d_entry_t working_dentry;

    if(read_dentry_by_name(filename, &working_dentry) == -1) return -1;        //if an equivalent d_entry was not found, return -1
    


    uint8_t * working_buffer = (uint8_t*)buf;    //typecast the void pointer
    int32_t length = nbytes;


    int inode_index = working_dentry.inode_number;


    return read_data(inode_index, offset, working_buffer, length);     //read length bytes from the beginning of the file to the buffer


}



/*==================DIRECTORY HANDLERS============================*/


/*    int32_t open_directory(const uint8_t* filename)
    Opens a directory described by the given filenamd
    Inputs: file name of directory to open
    Outputs: None
    Return: 0 if the directory is found in the filesystem, -1 if it is not found
    Side effects: None
*/
int32_t open_directory(const uint8_t* filename){

    //int file_desc;        //file descriptor associated with the file to be opened

    d_entry_t working_dentry;

    if(read_dentry_by_name(filename, &working_dentry) == -1) return -1;        //if an equivalent d_entry was not found, return -1



    return 0;

}


/*    int32_t read_directory(int32_t fd, void* buf, int32_t nbytes)
    Reads from a given directory into a given buffer
    Inputs: file descriptor of directory to copy from, buffer to copy to, number of bytes to copy (not used)
    Outputs: None
    Return: number of bytes successfully copied
    Side effects: None
*/
int32_t read_directory(int32_t fd, void* buf, int32_t nbytes){

    int directory_read_index = CURRENT_PCB_ADDRESS->fd_array[fd].position;    //find the current position in the directory from the fd array

    boot_block_t working_block;
    init_boot_block(&working_block);
    d_entry_t * working_dentry;
    int i;
    uint32_t length;
    //uint8_t * overflow = (uint8_t*)"END OF DIRECTORY";

    uint8_t * working_buffer = (uint8_t*)buf;

    working_dentry = working_block.boot_entries;
    if(directory_read_index < working_block.d_entries_count)
    {
        length = strlen((working_dentry[directory_read_index]).filename);
        if (length > STR_LEN)
        {
            length = STR_LEN;
        }

        for(i=0;i<length;i++)
        {
            working_buffer[i] = ((working_dentry[directory_read_index]).filename)[i];
        }
        directory_read_index++;
        CURRENT_PCB_ADDRESS->fd_array[fd].position = directory_read_index;
        return length;    //return the number of bytes copied
    }

    directory_read_index++;
    CURRENT_PCB_ADDRESS->fd_array[fd].position = directory_read_index;

    //close the fd
    sys_close(fd);

return 0;
}



/*    int32_t write_directory(int32_t fd, const void* buf, int32_t nbytes)
    Writes to a given directory. Not implemented in read-only file system
    Inputs: file descriptor of directory to write to, buffer to write from, number of bytes to write
    Outputs: None
    Return: -1 on failure
    Side effects: None
*/
int32_t write_directory(int32_t fd, const void* buf, int32_t nbytes){
    

    return -1;
}



/*    int32_t close_directory(int32_t fd)
    Closes the directory associated with the given file descriptor
    Inputs: file descriptor of directory to close
    Outputs: None
    Return: 0 on success
    Side effects: None
*/
int32_t close_directory(int32_t fd){

    return 0;
}



/*    int32_t read_directory_placeholder(void* buf)
    Copies next filename in directory sequence into the given buffer
    Inputs: buffer to copy name to
    Outputs: Filename to the given buffer
    Return: number of bytes successfully copied
    Side effects: Buffer filled with filename
*/
int32_t read_directory_placeholder(void* buf)
{

    boot_block_t working_block;
    init_boot_block(&working_block);
    d_entry_t * working_dentry;
    int i;
    //uint8_t * overflow = (uint8_t*)"END OF DIRECTORY";

    uint8_t * working_buffer = (uint8_t*)buf;

    working_dentry = working_block.boot_entries;
    if(directory_read_index < working_block.d_entries_count)
    {
        for(i=0;i<STR_LEN;i++)
        {
            working_buffer[i] = ((working_dentry[directory_read_index]).filename)[i];
        }
        directory_read_index++;
        return STR_LEN;    //return the number of bytes copied
    }



    return 0;

}



/*==================READ ROUTINES============================*/



/*    int32_t read_dentry_by_name(const uint8_t* filename, d_entry_t * fill)
    Initializes an input d_entry_t structure to hold that of the file described by the file name input
    Inputs: filename to find, d_entry struct to fill
    Outputs: None
    Return: 0 on success, -1 on failure
    Side effects: initializes the d_entry_t pointed to by fill to hold the correct d_entry data
*/
int32_t read_dentry_by_name(const uint8_t* filename, d_entry_t * fill)
{
    int i,j, equivalent;
    int gdb_test = 1;
    boot_block_t working_block;
    d_entry_t * iterator;
    d_entry_t * test;
    uint8_t compare[STR_LEN];

    init_boot_block(&working_block);            //setup the boot block to retrieve data
    iterator = working_block.boot_entries;        //set the iterator to point to the first d_entry
    int limit = working_block.d_entries_count;

    int length = strlen((char*)filename);
    if(length>STR_LEN) return -1;                //if a name of greater than 32 chars is passed in, return an error


    for(i=0;i<STR_LEN;i++)                                //converts the input into a zero-padded string of length 32
    {
        if(i<length) compare[i] = filename[i];
        else compare[i] = 0;
    }



    for(i=0;i<limit;i++)            //iterate through dir entries
    {    
        equivalent = 1;    
        test = iterator + i;
        for(j=0;j<STR_LEN;j++)                //iterate through all 32 characters
        {
            if((test->filename)[j] != compare[j]){
                equivalent = 0;                //indicate the strings are not equivalent as soon as a different character is found
                break;
            }
            else
            {
                gdb_test = 0;
            }

        }

        if(equivalent)        //if the equivalent dentry is found, poit fill to that entry and return 0 for success
        {
            (*fill) = (*test);
            return 0;
        }

    }

    fill = NULL;    //if the equivalent d_entry is not foud, set fill to NULL and return -1;
    return -1;


}



/*    int32_t read_dentry_by_index(int index, d_entry_t * fill)
    Initializes an input d_entry_t structure to hold the d_entry structure at an index in the list of d_entries
    Inputs: index of d_entry in boot block, d_entry struct to fill
    Outputs: None
    Return: 0 on success, -1 on failure
    Side effects: initializes the d_entry_t pointed to by fill to hold the correct d_entry data
*/
int32_t read_dentry_by_index(int index, d_entry_t * fill)
{

    boot_block_t working_block;
    init_boot_block(&working_block);            //setup the boot block to retrieve data
                    
    if(index<0 || index>=(working_block.d_entries_count)) return -1;                //if the equivalent d_entry is not foud, return -1;

    d_entry_t * iterator = working_block.boot_entries;
    *fill = iterator[index];
    return 0;

}



/*    int32_t read_data(inode_t inode, uint32_t offset, uint8_t* buf, uint32_t length)
    Copies data from a file indicated by the given inode into a given buffer
    Inputs: inode index for the given file, offset into the file to copy from in bytes, buffer to copy to, length of data to copy in bytes
    Outputs: Data to the given buffer
    Return: number of bytes successfully copied
    Side effects: Buffer filled with data from file
*/
int32_t read_data(uint32_t inode_index, uint32_t offset, uint8_t* buf, uint32_t length)
{

    int32_t i,starting_data_block, starting_offset;
    boot_block_t working_block;
    int32_t num_blocks;
    init_boot_block(&working_block);
    uint32_t first_iter = 1;
    uint32_t bytes_copied = length;

    inode_t inode;

    get_inode(inode_index, &inode);

    if(offset>inode.length) return 0;        
    
    if(offset + length > inode.length)    //if the caller asks for data past the limits of the file, only copy from the offset to the end of the file
    {
        length = inode.length - offset;
        bytes_copied = length;
    }     



    starting_data_block = offset / BLOCK_SIZE;        //find which block to start at
    starting_offset = offset % BLOCK_SIZE;            //find where in starting_data_block to start copying from    
    uint8_t * start = filesys_img + (working_block.inodes_count + 1)*BLOCK_SIZE;    //skip over first block (boot block) and inode blocks to point to beginning of data section
    uint8_t * curr_data;
    int buffer_offset = 0;


    num_blocks = length/BLOCK_SIZE;        //number of FULL blocks to be copied

    for(i=starting_data_block;i<starting_data_block + num_blocks;i++)        //iterate through each 4KB block of data
    {
        //start indicates the starting address of the data blocks array in the file system
        //inode.data_blocks[i] is the index of the current data block to jump to
        //first_iter * starting_offset is used when the offset points to memory that isn't a multiple of 4096    
        curr_data = start + (BLOCK_SIZE * (inode.data_blocks)[i]) + (first_iter * starting_offset);    

        if(first_iter)
        {
            memcpy(buf, curr_data, BLOCK_SIZE - starting_offset);
            length -= (BLOCK_SIZE - starting_offset);            //keep track of how much data is left to copy        
            first_iter = 0;
            buffer_offset+=BLOCK_SIZE-starting_offset;
        }

        else 
        {
            memcpy(buf + buffer_offset,curr_data,BLOCK_SIZE);
            //decrement length by 4096 each iteration in order to keep track of the number of bytes left to copy
            length -= BLOCK_SIZE;
            buffer_offset += BLOCK_SIZE;
        }



    }

    i = starting_data_block + num_blocks;    //copy leftover data from the last block

    curr_data = start + (BLOCK_SIZE*(inode.data_blocks)[i]) + (first_iter*starting_offset);        //point curr_data to the final data block to be copied
    memcpy(buf + buffer_offset, curr_data, length);            

    return bytes_copied;


}


/*==================HELPER FUNCTIONS============================*/


/*    int32_t init_boot_block(boot_block_t * working_block)
    Initializes a boot block structure to hold the data of the current boot block
    Inputs: pointer to a boot block structure
    Outputs: None
    Return: 0 on success
    Side effects: alters the data of the input block to describe the current boot block
*/
int32_t init_boot_block(boot_block_t * working_block)
{    
    d_entry_t * temp_dentry;

    boot_block_t * temp = (boot_block_t*)filesys_img;
    *working_block = *temp;    //set the dir_entries, inodes_count, data_blocks_count for the working block
    temp_dentry = (d_entry_t*)filesys_img;
    working_block->boot_entries = temp_dentry + (DIR_OFFSET/sizeof(d_entry_t)); //set the boot_entries pointer to the correct location of the 4KB block
                                                                                //divide by size of d_entry_t to get offset in bytes

    return 0;
}





/*    void init_file_io()
    Initializes any parameters corresponding with the file_io. Called during kernel boot sequence
    Inputs: None
    Outputs: None
    Return: None
    Side effects: initializes file io data
*/
void init_file_io(){

}


/*    int32_t file_size(const uint8_t* filename)
    Finds the file size of a file given a file name
    Inputs: Filename
    Outputs: None
    Return: size of the file in bytes, -1 if the file is not found
    Side effects: None
*/
int32_t file_size(const uint8_t* filename)
{
    boot_block_t working_block;
    init_boot_block(&working_block);
    d_entry_t working_dentry;
    int retval;

    if(read_dentry_by_name(filename, &working_dentry) == -1) return -1;        //if an equivalent d_entry was not found, return -1


    inode_t * inodes_list = (inode_t*)filesys_img;
    inodes_list+=BLOCK_SIZE/sizeof(inode_t);    //point to the beginning of the inodes list (skip over boot block)

    int inode_index = working_dentry.inode_number;


    int inode_offset = (BLOCK_SIZE*inode_index)/sizeof(inode_t);

    inode_t * temp_inode = inodes_list + inode_offset;

    retval =  *((int*)temp_inode);                //jump to correct inode in inode array and return the first integer value (the size)
    return (int32_t)retval;

}



/*    int32_t get_inode(uint32_t inode_number, inode_t * inode_buffer)
    Copies data from the inode at the given index into the inode buffer
    Inputs: inode index of inode to be copied, inode pointer to inode to copy to
    Outputs: Data to the given inode
    Return: 0 on success
    Side effects: inode filled with data from the filesys
*/
int32_t get_inode(uint32_t inode_number, inode_t * inode_buffer)
{
    inode_t inode;
    inode_t * inodes_list = (inode_t*)filesys_img;
    inodes_list+=BLOCK_SIZE/sizeof(inode_t);    //point to the beginning of the inodes list (skip over boot block)



    int inode_offset = (BLOCK_SIZE*inode_number)/sizeof(inode_t);
    inode_t * temp_inode = inodes_list + inode_offset;

    inode.length = *((int*)temp_inode);                //jump to correct inode in inode array
    inode.data_blocks = (int*)temp_inode + 1;        //point data_blocks to the second 4 bytes of the inode, 1 int over

    (*inode_buffer) = inode;

    return 0;

}




