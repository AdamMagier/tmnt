#include "tests.h"
#include "x86_desc.h"
#include "lib.h"
#include "handlers.h"
#include "keyboard.h"
#include "rtc.h"
#include "rtc_drivers.h"
#include "file_drivers.h"


#define FRAME_SIZE 198                //size of frame0.txt
#define SMALL_OFFSET_TEST 50        //arbitrary offset for testing
#define LARGE_TEXT_SIZE 5310        //size of verylargetextwithverylongname.txt
#define END_OF_FILE_TEST 310        //arbitrary value for testing end of file reading
#define COPY_FROM_EXE_TEST 300        //arbitrary number of bytes to copy from exe for testing
#define PRINT_AS_HEX 16                //number of values to print to the screen as hexadecimal for executables




/*    int32_t iterate_through_directory_test()
    Iteratively reads all filenames of directory and ensures that any subsequent directory reads return 0
    Inputs: None
    Outputs: None
    Return: 0 on success, -1 on failure
    Side effects: Prints all filenames of the directory
*/
int32_t iterate_through_directory_test()
{    
    int i,j;
    boot_block_t working_block;
    init_boot_block(&working_block);            //setup the boot block to retrieve data
    uint8_t buf[STR_LEN];

    printf("DIRECTORY READING TEST\n");
    for(i=0;i<working_block.d_entries_count;i++)
    {
        if(!read_directory_placeholder((void*)buf)) return -1;
        for(j=0;j<STR_LEN;j++) printf("%c", buf[j]);
        printf("\n");
    }

    if(read_directory_placeholder((void*)buf)) return -1;

    return 0;

}


/*    int32_t copy_entire_file_test()
    Copies all of frame0.txt into a buffer, ensures that the read_data retval is correct, and prints frame0 to the screen
    Inputs: None
    Outputs: None
    Return: 0 on success, -1 on failure
    Side effects: Prints frame0.txt
*/
int32_t copy_entire_file_test()
{
    int i;
    int32_t copied_bytes;
    d_entry_t working_dentry;
    uint8_t * filename = (uint8_t*)"frame0.txt";
    if(read_dentry_by_name(filename, &working_dentry)==-1) return -1;        //check that read_dentry finds the file in the image
    int32_t nbytes = file_size(filename);
    uint8_t buffer[FRAME_SIZE];

    copied_bytes = read_file_placeholder(filename, (void*)buffer, nbytes, 0);                //read the file into the buffer at an offset of 0
    if(copied_bytes!=nbytes) return -1;

    printf("PRINTING FRAME 0 OF FISH\n");
    for(i=0;i<nbytes;i++)
    {
        printf("%c", buffer[i]);
    }

    printf("\n");


    return 0;

}



/*    int32_t copy_large_file_test()
    Copies all of verylargetextwithverylongname.txt into a buffer, ensures that the read_data retval is correct, and prints the text to the screen
    Inputs: None
    Outputs: None
    Return: 0 on success, -1 on failure
    Side effects: Prints verylargetextwithverylongname.txt
*/
int32_t copy_large_file_test()
{

    int i;
    int32_t copied_bytes;
    d_entry_t working_dentry;
    uint8_t * filename = (uint8_t*)"verylargetextwithverylongname.tx";
    if(read_dentry_by_name(filename, &working_dentry)==-1) return -1;        //check that read_dentry finds the file in the image
    int32_t nbytes = file_size(filename);
    uint8_t buffer[LARGE_TEXT_SIZE];

    copied_bytes = read_file_placeholder(filename, (void*)buffer, nbytes, 0);                //read the file into the buffer at an offset of 0
    if(copied_bytes!=nbytes) return -1;

    printf("PRINTING LARGE TEXT\n");
    for(i=0;i<nbytes;i++)
    {
        printf("%c", buffer[i]);
    }

    printf("\n");


    return 0;
    
}




/*    int32_t copy_large_file_test()
    Copies data from frame0 at a small offset, checks the read return value, and prints the partial frame
    Inputs: None
    Outputs: None
    Return: 0 on success, -1 on failure
    Side effects: Prints part of frame0.txt
*/
int32_t copy_from_file_at_offset_test()
{
    int i;
    int32_t test_offset = SMALL_OFFSET_TEST;            //test by reading at an offset of 50 bytes
    int32_t copied_bytes;
    d_entry_t working_dentry;
    uint8_t * filename = (uint8_t*)"frame0.txt";
    if(read_dentry_by_name(filename, &working_dentry)==-1) return -1;        //check that read_dentry finds the file in the image
    int32_t nbytes = file_size(filename);
    uint8_t buffer[FRAME_SIZE - SMALL_OFFSET_TEST];

    copied_bytes = read_file_placeholder(filename, (void*)buffer, nbytes, test_offset);                //read the file into the buffer at an offset 
    if(copied_bytes!=(nbytes-test_offset)) return -1;

    printf("PRINTING PARTIAL FRAME 0 OF FISH\n");
    for(i=0;i<nbytes-test_offset;i++)
    {
        printf("%c", buffer[i]);
    }

    printf("\n");


    return 0;



}


/*    int32_t copy_end_of_file_test()
    Copies data from large text file at an offset and length that reaches the past the end of the file
    Ensures that the data is only copied from the offset to the end
    Inputs: None
    Outputs: None
    Return: 0 on success, -1 on failure
    Side effects: Prints part of verylargetextwithverylongname.txt
*/
int32_t copy_end_of_file_test()
{


    int i;
    int32_t copied_bytes;
    int32_t test_offset = LARGE_TEXT_SIZE - END_OF_FILE_TEST;        //read from the last END_OF_FILE_TEST bytes of the file
    d_entry_t working_dentry;
    uint8_t * filename = (uint8_t*)"verylargetextwithverylongname.tx";
    if(read_dentry_by_name(filename, &working_dentry)==-1) return -1;        //check that read_dentry finds the file in the image
    int32_t nbytes = file_size(filename);
    uint8_t buffer[END_OF_FILE_TEST];

    copied_bytes = read_file_placeholder(filename, (void*)buffer, nbytes, test_offset);                //read the file into the buffer at an offset of 0
    if(copied_bytes!=nbytes-test_offset) return -1;

    printf("PRINTING END OF LARGE TEXT\n");
    for(i=0;i<nbytes-test_offset;i++)
    {
        printf("%c", buffer[i]);
    }

    printf("\n");


    return 0;
    

}

int32_t copy_beginning_of_exe_test()
{
    int i;
    int32_t copied_bytes;
    int32_t test_offset = 0;
    d_entry_t working_dentry;
    uint8_t * filename = (uint8_t*)"cat";
    if(read_dentry_by_name(filename, &working_dentry)==-1) return -1;        //check that read_dentry finds the file in the image
    uint8_t buffer[END_OF_FILE_TEST];
    copied_bytes = read_file_placeholder(filename, (void*)buffer, COPY_FROM_EXE_TEST, test_offset);        //read the file into the buffer at an offset of 0
    if(copied_bytes!=COPY_FROM_EXE_TEST) return -1;

    printf("PRINTING BEGINNING OF EXECUTABLE\n");
    for(i=0;i<PRINT_AS_HEX;i++)
    {
        printf("%x", buffer[i]);
    }

    for(i=PRINT_AS_HEX;i<COPY_FROM_EXE_TEST;i++)
    {
        printf("%c", buffer[i]);
    }

    printf("\n");

    return 0;

}


/*    int32_t read_dentry_by_name_test()
    Tests that read_dentry_by_name finds the file given the name of an existent filename and returns -1 given an invalid filename
    In the case of a valid file input, ensures that the dentry found is correct by comparing the input string to the dentry string
    Inputs: None
    Outputs: None
    Return: 0 on success, -1 on failure
    Side effects: None
*/
int32_t read_dentry_by_name_test()
{

    //READS THAT SHOULD PASS
    int i;
    int string_length;
    uint8_t* filename;
    filename = (uint8_t*)"frame0.txt";
    d_entry_t working_dentry;
    if(read_dentry_by_name(filename, &working_dentry)==-1) return -1;        //check that read_dentry finds the file in the image

    string_length = strlen((char*)filename);

    for(i=0;i<STR_LEN;i++)    //compare the names to check that the dentry holds the correct file name
    {
        if(i<string_length)
        {
            if(filename[i]!=(working_dentry.filename)[i]) return -1;
        }

        else if ((working_dentry.filename)[i] != 0) return -1;
    }


    filename = (uint8_t*)(uint8_t*)"verylargetextwithverylongname.tx";    //check that read_dentry finds the file in the image
    if(read_dentry_by_name(filename, &working_dentry)==-1) return -1;
    string_length = strlen((char*)filename);

    for(i=0;i<STR_LEN;i++)    //compare the names to check that the dentry holds the correct file name
    {
        if(i<string_length)
        {
            if(filename[i]!=(working_dentry.filename)[i]) return -1;
        }

        else if ((working_dentry.filename)[i] != 0) return -1;
    }


    //READS THAT SHOULD FAIL


    filename = (uint8_t*)"verylargetextwithverylongname.txt";        //ensure that read_dentry rejects strings of length>32
    if(read_dentry_by_name(filename, &working_dentry)!=-1) return -1;


    filename = (uint8_t*)"trash.madeupfileextension";                //ensure that read_dentry rejects filenames that aren't in the system
    if(read_dentry_by_name(filename, &working_dentry)!=-1) return -1;


    return 0;


}


/*    int32_t read_dentry_by_index_test()
    Tests that read_dentry_by_index fails when it should and passes when it should
    Inputs: None
    Outputs: None
    Return: 0 on success, -1 on failure
    Side effects: None
*/
int32_t read_dentry_by_index_test()
{
    d_entry_t working_dentry;

    //TEST THAT SHOULD PASS
    boot_block_t working_block;
    init_boot_block(&working_block);            //setup the boot block to retrieve data
    int index = 0;


    if(read_dentry_by_index(index,&working_dentry)) return -1;

    //TEST THAT SHOULD FAIL

    index = working_block.d_entries_count + 1;

    if(!read_dentry_by_index(index,&working_dentry)) return -1;

    return 0;


}



/*    int32_t launch_file_tests()
    Cycles through all filesystem tests
    Inputs: None
    Outputs: None
    Return: 0 on success, -1 on failure
    Side effects: None
*/
int32_t launch_file_tests()
{

    if(read_dentry_by_name_test())    return -1;
    if(read_dentry_by_index_test()) return -1;
    if(iterate_through_directory_test()) return -1;
    if(copy_entire_file_test()) return -1;
    if(copy_large_file_test()) return -1;
    if(copy_from_file_at_offset_test()) return -1;
    if(copy_end_of_file_test()) return -1;
    if(copy_beginning_of_exe_test()) return -1;
    return 0;
}





