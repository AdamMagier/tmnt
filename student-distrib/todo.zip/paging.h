/* paging.h - Set up paging
 * vim:ts=4 noexpandtab
 */

#ifndef _PAGING_H
#define _PAGING_H

#include "lib.h"
#include "process.h"

#define SIZE_TABLE 1024
#define ALIGNMENT_SIZE 4096
#define GRAPHICS_ADDR 184
#define GRAPHICS_LOCATION 0xB8000
#define NOT_PRESENT 0x00000002
#define PAGE_SIZE 0x1000
#define PAGE_4MB 0x400000
#define PAGE_128MB 0x8000000
#define ENTRY_128MB 32
#define PAGE_OFF 2
#define PAGE_ON 3
#define MB_PAGE_ON 0x80
#define DIRECTORY_MASK 0xFFC00000     //masks out bottom 22 bits
#define DIRECTORY_OFFSET 22              //isolate Page Base address
#define TABLE_OFFSET 12                    //isolate base table entry address

#define USER_LVL 4
#define GLOBAL_PAGE 0x100

#define NUM_DIRECTORIES 1            //the idea is there should be no limit to the number. Doesn't quite work like that but idk
#define PAGE_TABLE_MASK 0xFFFFF000    //mask out bottom 12 bits
#define PAGE_TABLE_ENTRY_MASK 0x3FF000    //middle 10 bits
#define LAST_BIT_MASK 0xFFFFFFFE
#define TABLE_MASK 0x3FF                //keep 10 bottom bits

#define TERMINAL_1_VIDEO_MEM 0xB9000
#define TERMINAL_2_VIDEO_MEM 0xBA000
#define TERMINAL_3_VIDEO_MEM 0xBB000

#define VIDMEM_TABLE 33


//ASSEMBLY
//assembly subroutine which loads paging registers
extern void load_pages(unsigned int*);
//assembly subroutine which flushes TLBs
extern void flush_TLB(void);
//assembly subroutine which sets a new directory
extern void change_dir(unsigned int*);
//sets up paging
extern void paging_init(void);
//get pointer for the current paging directory
extern uint32_t* get_page_directory(void);

//NOT ASSEMBLY
//get new directory or table. Cuts down on spaghetti code.
uint32_t* get_new_entry(void);

//modify 4mB page
int page_modify(uint32_t virt_addr, uint32_t phys_addr, uint32_t priv_lvl);

//set up new 4kb user page somewhere 
int32_t map_virt_to_phys(uint8_t* virt_addr, uint8_t* phys_addr);

//get entry at provided virtual address
uint32_t* get_PTE(uint32_t* virt_addr);
uint32_t* get_PDE(uint32_t* virt_addr);

//TESTS
//test paging 
void test_paging_pass(void);
//test paging
void test_paging_fail(void);
#endif 
