#ifndef PIT_DRIVERS_H
#define PIT_DRIVERS_H

#define PIT_IRQ 0x00

#define CHANNEL 0
#define CHANNEL_SHIFT 6
#define ACCESS_MODE 3
#define ACCESS_SHIFT 4
#define OPERATING_MODE 3
#define OPERATING_MODE_SHIFT 1
#define BINARY_MODE 0
#define _40_HZ  29830 //40Hz = 25ms

#define MODE_CMD_REGISTER 0x43
#define CHANNEL_0_DATAPORT 0x40

#define ONE_BYTE 8
#define LOWMASK 0xFF
#define HIGHMASK 0xFF00

#define C_2 65
#define Eb_2 78
#define F_2 87
#define G_2 98
#define Ab_2 104
#define A_2 110
#define Bb_2 117
#define C_3 131
#define Eb_3 156
#define F_3 175

#define C_3 131
#define Eb_3 156
#define F_3 175
#define G_3 196
#define Ab_3 208
#define A_3 220
#define Bb_3 233
#define C_4 262
#define Eb_4 311
#define F_4 349

#define G5  784
#define A5  880
#define AF5 830
#define C5  523
#define BF5 466

#define EIGHTH  1
#define QUARTER 2
#define TIE_EQ  3

#define SONG_LENGTH 33

/* Initialize the PIT to 40Hz (25ms). */
extern void init_pit();

extern void beep(int freq, int duration);

extern void play_turtles();

typedef struct {
    int freq;
    int duration;
} note_t;

// note_t song[] = {quarter_G, quarter_G, quarter_G, quarter_G, quarter_G, eighth_G, tied_G, quarter_G,
               // quarter_G, quarter_G, quarter_G, quarter_G, quarter_G, eighth_G, tied_G, quarter_G,
               // quarter_A, quarter_A, quarter_A, quarter_A,
               // quarter_AF, eighth_AF, tied_AF, quarter_AF,
               // eighth_C, eighth_C, eighth_C, eighth_C, quarter_BF, quarter_C


#endif
