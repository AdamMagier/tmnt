/* paging.c - Function to set up paging
 * vim:ts=4 noexpandtab
 */
#include "paging.h"

//page directory for memory space, plus page table for physical memory 0-4MB
static uint32_t page_directory[SIZE_TABLE] __attribute__((aligned(ALIGNMENT_SIZE)));    //make 1024 sized table, aligned to 4kb
static uint32_t page_table[SIZE_TABLE] __attribute__((aligned(ALIGNMENT_SIZE)));        //make 1024 table, aligned to 4kb
static uint32_t page_table2[SIZE_TABLE] __attribute__((aligned(ALIGNMENT_SIZE)));          //make 1024 table, aligned to 4kb

/*
 * paging_init()
 *     DESCRIPTION: Sets up paging, page directory, and a single page table
 *                    for memory between 0MB and 4MB in physical memory.
 *     INPUTS:none
 *     OUTPUTS: none
 *     RETURN VALUE: none
 *     SIDE EFFECTS: Enables paging
 */
void paging_init(void)
{
    int i,j;
    uint32_t* cur_dir;
    uint32_t* cur_table;
   // int cur_graphics_addr;
    
    page_directory[0] = ((unsigned int)page_table) | PAGE_ON;                    //Put the page table into first entry of page directory
    cur_dir = page_directory;
        
    for(i = 1; i < SIZE_TABLE; i++){
        cur_dir[i] = NOT_PRESENT;                                                //initially set all page tables to not present, r/w mode
    }
    
    cur_table = (uint32_t*)(cur_dir[0] & PAGE_TABLE_MASK);                        //get address for page table 0
    for(i = 0; i<SIZE_TABLE; i++){
        cur_table[i] = (i*PAGE_SIZE)|PAGE_OFF;                                    //supervisor level, r/w set, marked not present (online example used 3, assumes present)
    }
    
    for (i = 160; i < 192; i++)
    {
        cur_table[i] = (i*PAGE_SIZE)|PAGE_ON; // MODEX SHITTITITITITITIT
    }
    
    cur_table[GRAPHICS_ADDR] = (GRAPHICS_ADDR*PAGE_SIZE | PAGE_ON);                //set video memory to present, entry 184 in table
    cur_table[GRAPHICS_ADDR+1] = (TERMINAL_1_VIDEO_MEM | PAGE_ON);        //set video memory to present, entry 184 in table
    cur_table[GRAPHICS_ADDR+2] = (TERMINAL_2_VIDEO_MEM | PAGE_ON);        //set video memory to present, entry 184 in table
    cur_table[GRAPHICS_ADDR+3] = (TERMINAL_3_VIDEO_MEM | PAGE_ON);        //set video memory to present, entry 184 in table
    
    cur_dir[1] = (PAGE_4MB) | GLOBAL_PAGE | MB_PAGE_ON | PAGE_ON;              //0x80 sets Page Size (bit 7) to 1, indicating a 4MB page. Set to present
                                                                            //at location 4MB (=2^22 = 0x400000) in memory
    //set up user memory            
    cur_dir[ENTRY_128MB] = ((PAGE_OFF+j)*PAGE_4MB) | MB_PAGE_ON| USER_LVL |PAGE_OFF;    //first user program loads at 8MB
    cur_dir[VIDMEM_TABLE] = (unsigned int)page_table2 | USER_LVL | PAGE_ON;
            
    page_table2[0] = (GRAPHICS_LOCATION) |USER_LVL | PAGE_ON;
    load_pages(cur_dir);                            //have first directory act as base memory map

}

/*
 * get_new_entry()
<<<<<<< HEAD
 *     DESCRIPTION: Creates a new aligned array of size 1024 entries (4B each).s
 *     INPUTS: None
 *     RETURN VALUE: A pointer to the aligned array
=======
 *     DESCRIPTION: Allocate a new 4kb sized array, aligned to 4096. All 1024 entries are set to not present. 
 *                    Can be used for a new directory or page table.
 *     INPUTS:none
 *     OUTPUTS: none
 *     RETURN VALUE: pointer to new array, located in kernel space, aligned to 4096
 *     SIDE EFFECTS: none
>>>>>>> a69dbd830aaf527e68c9209d01eff286257f103e
 */
uint32_t* get_new_entry(void){
    static uint32_t thingy[SIZE_TABLE] __attribute__((aligned(ALIGNMENT_SIZE)));    //make 1024 sized table, aligned to 4kb
    int i;
    for(i = 1; i < SIZE_TABLE; i++)
    {
        thingy[i] = NOT_PRESENT;                                //initially set all page tables to not present, r/w mode
    }
    return thingy;    
}

/*
 * Page Modify
 *     DESCRIPTION: allows editing a 4mb page in the page directory. 
 *     INPUTS: virt_addr = what input address should be mapped
               phys_addr = the address virt_addr should map to
               priv_lvl  = whether page should be user level or kernel level
 *     RETURN VALUE: -1 if bad inputs. 0 for success.
 *     SIDE EFFECTS: Changes a single 4MB page in the page directory
 */
int page_modify(uint32_t virt_addr, uint32_t phys_addr, uint32_t priv_lvl){
    if(virt_addr < 2 * PAGE_SIZE)
        return -1;                //Don't allow dereferencing NULL, protec kernel
    if(phys_addr < 2 * PAGE_SIZE)
        return -1;                //Don't allow dereferencing NULL, protec kernel
    if(priv_lvl != 0)
        priv_lvl = USER_LVL;
    uint32_t directory_idx = virt_addr >> DIRECTORY_OFFSET;                //obtain the index in the directory
    uint32_t directory_value = (phys_addr & DIRECTORY_MASK) | MB_PAGE_ON| priv_lvl | PAGE_ON;    //mask off first 22 bits, fill in required information
    
    page_directory[directory_idx] = directory_value;
    flush_TLB();
    
    return directory_value;
}


/* Directory Modify
 * DESCRIPTION: Switches the page directory for new_ptr. This allows 
 *              having multiple paging structures, which simplifies context switching 
 *                but also makes it fast. 
 *    INPUTS: new_ptr = new directory to load into the hardware
 *    RETURN VALUE: 0 on success, -1 on failure
 *    SIDE EFFECTS: Virtual addresses now set according to the new_ptr page directory
*/
int directory_change(uint32_t* new_ptr){
    if((uint32_t)new_ptr < PAGE_SIZE){
        return -1;
    }
    change_dir(new_ptr);
    return 0;    
}


/* map_vidmem_to_address
 * DESCRIPTION: Allocates a 4kb page which maps to video memory, located at 0xB8000, and sets the virtual address
 *                to the given input, screen_start.
 * INPUTS:      virt_addr: the virtual address to map video memory to
 *                phys_addr: what to put in the PTE at the given virtual address
 * RETURN VALUE: -1 for failure, 0 for success
 * SIDE EFFECTS: sets up a user-level page table which maps memory from 132MB-136MB
*/
int32_t map_virt_to_phys(uint8_t* virt_addr, uint8_t* phys_addr)
{
    int32_t retval;
    if((uint32_t)virt_addr == 0)                                                //Basic error check. Will catch NULL pointers at least
    {
        return -1;
    }
    if(((uint32_t)virt_addr < 2*FOUR_M) && (uint32_t)virt_addr > FOUR_M){
        return -1;                                                                //protec kernel
    }
    if(((uint32_t)phys_addr < 2*FOUR_M) && (uint32_t)phys_addr > FOUR_M){
        return -1;                                                                //protec kernel
    }
    
    
    //get current in-use directory straight from cr3 (not fully necessary but might come into play with changes to paging)
    uint32_t* dir = page_directory;
    uint32_t table_idx = ((uint32_t)virt_addr>>TABLE_OFFSET) & TABLE_MASK;            //entry in page table to use
    uint32_t directory_idx = (uint32_t)virt_addr >> DIRECTORY_OFFSET;                //obtain the index in the directory
    
    uint32_t priv_lvl = 0;
    if(directory_idx == VIDMEM_TABLE){
        priv_lvl = USER_LVL;
    }
    
    uint32_t* PDE = (uint32_t*)dir[directory_idx];
    if(((uint32_t)PDE & 0x1) == 0)                                          //check bit 0, the present bit. If this trips, in all likelyhood the inputs are bad.
    { 
        return -1;                                                                     //populate with new page table if necessary
    }
    PDE = (uint32_t*)((uint32_t)PDE & PAGE_TABLE_MASK);
        
    retval = (unsigned int)phys_addr |priv_lvl | PAGE_ON;                                 //let user play with chunk of memory
    PDE[table_idx] = retval;
    dir[directory_idx] = (unsigned int)PDE |priv_lvl | PAGE_ON;                //stick new table into directory.
        
    flush_TLB();
    //return success;
    return 0;
}


//malloc functions

/* get_PTE(virt_addr)
 * DESCRIPTION: Gets the page table entry for the provided virtual address. 
 * INPUTS:      virt_addr: the virtual address to pull the PTE for
 * OUTPUTS:        none
 * RETURN VALUE: NULL if PTE is not present or if accessing a 4mb page
 * SIDE EFFECTS: none
*/

uint32_t* get_PTE(uint32_t* virt_addr)
{
    uint32_t table_idx = ((uint32_t)virt_addr >> TABLE_OFFSET) & TABLE_MASK;
    uint32_t dir_idx = ((uint32_t)virt_addr & DIRECTORY_MASK) >> DIRECTORY_OFFSET;
    uint32_t test = (uint32_t)virt_addr;
    test = test & DIRECTORY_MASK;
    test = test >> DIRECTORY_OFFSET;
    if((page_directory[dir_idx] & 0x1) == 0)
    {
        return NULL;                                                                    //check PDE to see if present
    }
    if((page_directory[dir_idx] & MB_PAGE_ON) != 0)
    {
        return NULL;                                                                    //check PDE to make sure not at a 4mB page
    }
    uint32_t* table_addr = (uint32_t*)(page_directory[dir_idx] & PAGE_TABLE_MASK);        //get address for table
    return (uint32_t*)table_addr[table_idx];
}

/* get_PDE(virt_addr)
 * DESCRIPTION: Gets the directory entry for the provided virtual address. 
 * INPUTS:      virt_addr: the virtual address to pull the PDE for
 * OUTPUTS:        none
 * RETURN VALUE: value of PDE. May or may not be present.
 * SIDE EFFECTS: none
*/
uint32_t* get_PDE(uint32_t* virt_addr)
{
    uint32_t dir_idx = ((uint32_t)virt_addr) >> DIRECTORY_OFFSET;
    return (uint32_t*)page_directory[dir_idx];
}
