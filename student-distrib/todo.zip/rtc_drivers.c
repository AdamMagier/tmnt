#include "tests.h"
#include "x86_desc.h"
#include "lib.h"
#include "handlers.h"
#include "keyboard.h"
#include "rtc_drivers.h"
#include "rtc.h"
#include "process.h"
#include "scheduling.h"

#define STDERR 2
#define MASK 0xF0
#define BYTES_READ 4

#define RATE_MAX 6
#define _2_HZ 2
#define _4_HZ 4
#define _8_HZ 8
#define _16_HZ 16
#define _32_HZ 32
#define _64_HZ 64
#define _128_HZ 128
#define _256_HZ 256
#define _512_HZ 512

// Global variables for use with virtualizing the RTC 

int rtc_virtual_interrupt_counter = 0;
int virtual_frequency = INITIAL_FREQUENCY;

/* open_rtc
 * Description: Enable the RTC's Periodic Interrupt function and set to a 1024 Hz for virtualization.
 * Interrupts remain on at all times.
 * Inputs: Unused params for consistency with system call params.
 * Outputs: Returns 0
 */
int32_t open_rtc(const uint8_t* filename){
    uint32_t flags; /* Variable for storing the flags */
    cli_and_save(flags);
    //flip all params given by OSdev
    outb(RTC_REGISTER_A, RTC_PORT);        // set index to register A, disable NMI
    char prev=inb(RTC_PORT + 1);    // get initial value of register A
    outb(RTC_REGISTER_A, RTC_PORT);        // reset index to A
    outb(((prev & MASK) | RATE_MAX), RTC_PORT + 1); //write only our rate to A. Note, rate is the bottom 4 bits.
    restore_flags(flags);

    return 0;
}


/* read_rtc
 * Description: Return after an RTC interrupt has occurred. Uses a member variable of the pcb struct.
 * Inputs: Unused params for consistency with system call params.
 * Outputs: Returns 0 only after an interrupt has occurred.
 */
int32_t read_rtc(int32_t fd, void* buf, int32_t nbytes){
    // Reset the flag
    CURRENT_TASK.pcb->rtc_interrupt_occurred = 0;
    
    /* Spinning until rtc interrupt occurs */
    while (!(CURRENT_TASK.pcb->rtc_interrupt_occurred));
    
    return 0;
}


/* write_rtc
 * Description: Sets the psuedo-interrupt frequency of the virtualized RTC.
 * ONLY accepts powers of 2 between 2Hz and 1024 Hz.
 * Inputs: const void* buf: the target frequency
 * fd and nbytes: Unused params for consistency with system call params.
 * Outputs: Returns 0 on success, -1 on invalid frequency 
 */
int32_t write_rtc(int32_t fd, const void* buf, int32_t nbytes){
    int user_rate = *(int*)buf;
    if (user_rate > MAX_HZ || user_rate <= 0) {
        return -1;
    }
    // Valid frequencies are 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024. Faster than a case statement or algorithm.
    if (!(user_rate == _2_HZ || user_rate == _4_HZ  || user_rate == _8_HZ  || user_rate == _16_HZ  
    || user_rate == _32_HZ  || user_rate == _64_HZ  || user_rate == _128_HZ  || user_rate == _256_HZ  || user_rate == _512_HZ  || user_rate == MAX_HZ)){
        return -1;
    }
     
    /* from osdev: write the frequency */
    uint32_t flags; /* Variable for storing the flags */
    cli_and_save(flags);

    // Store this process's RTC frequency 
    pcb_t* pcb = CURRENT_PCB_ADDRESS;
    pcb->rtc_freq = user_rate;

    restore_flags(flags);

    return BYTES_READ;

}

/* close_rtc
 * Description: Close the RTC. Not used except for consistency with syscall device drivers.
 * Inputs: fd: Unused param for consistency with system call params.
 * Outputs: Returns 0
 */
int32_t close_rtc(int32_t fd){
    return 0;
}


