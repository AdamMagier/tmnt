
#include "x86_desc.h"
#include "handlers.h"


/* fill_idt
 * Fills the IDT with 32 standard exceptions as well as a system call, rtc, and ketboard interrupts.
 * All other entries in the IDT are marked not present.
 * Inputs: None
 * Outputs: Nne
 */
void fill_idt()
{
    int i;

    // Fill the first 22 IDT entries with defined exceptions
    for(i = 0; i<HARDWARE_EXCEPTIONS; i++){
        set_bits(idt + i);
        idt[i].present = 1;
        SET_IDT_ENTRY(idt[i], exception_jumptable[i]);
    }

    // Fill entries 22-32 with exceptions reserved by Intel
    for(i = HARDWARE_EXCEPTIONS; i < GENERIC_EXCEPTIONS; i++){
        set_bits(idt + i);
        idt[i].present = 1;
        //22nd entry in jumptable corresponds to generic exception, used for exceptions defined by intel
        SET_IDT_ENTRY(idt[i], exception_jumptable[22]);            
    }

    // Mark entries 32 - 255 as not present
    for(i = GENERIC_EXCEPTIONS; i < NUM_VEC; i++){
        set_bits(idt + i);
        //0x80 corresponds to the idt index for system calls
        if(i == SYS_CALL){
            idt[i].present = 1;
            idt[i].dpl = 3;
            SET_IDT_ENTRY(idt[i], asm_generic_system_call);                
        }
        //0x20 corresponds to the idt index for PIT interrupts
        else if(i == PIT_INTERRUPT){
            idt[i].present = 1;
            idt[i].reserved3 = 0;
            SET_IDT_ENTRY(idt[i], asm_pit_interrupt);        
        }
        //0x21 corresponds to the idt index for keyboard interrupts
        else if(i == KEYBOARD_INTERRUPT){
            idt[i].present = 1;
            idt[i].reserved3 = 0;
            SET_IDT_ENTRY(idt[i], asm_generic_keyboard_interrupt);        
        }
        //0x28 corresponds to the idt index for RTC interrupts
        else if(i == RTC_INTERRUPT){
            idt[i].present = 1;
            idt[i].reserved3 = 0;
            SET_IDT_ENTRY(idt[i], asm_generic_RTC_interrupt);        
        }
        //0x2C corresponds to the idt index for RTC interrupts
        else if(i == MOUSE_INTERRUPT){
            idt[i].present = 1;
            idt[i].reserved3 = 0;
            SET_IDT_ENTRY(idt[i], asm_generic_mouse_interrupt);        
        }
            
        else{
            idt[i].present = 0;
            SET_IDT_ENTRY(idt[i], 0);

        }
    }

}

/* set_bits
 * Set idt struct attributes that are common to each entry. 
 * Inputs: A pointer to an idt struct
 * Outputs: None
 * Side effects: Sets reserved bits 0-4, segment selector, DPL, and size 
 */
void set_bits(idt_desc_t * entry){
        entry->reserved0 = 0;
        entry->reserved1 = 1;
        entry->reserved2 = 1;
        entry->reserved3 = 1;
        entry->reserved4 = 0;
        entry->seg_selector = KERNEL_CS;
        entry->dpl = 0;
        entry->size = 1;
}
