/* handlers.c - interrupts for the IDT */

#include "multiboot.h"
#include "x86_desc.h"
#include "lib.h"
#include "i8259.h"
#include "rtc.h"
#include "rtc_drivers.h"
#include "keyboard.h"
#include "terminal.h"
#include "debug.h"
#include "tests.h"
#include "handlers.h"
#include "sys_call.h"
#include "pit_drivers.h"
#include "scheduling.h"
#include "mouse.h"

#define HALTNUM (uint8_t)256

/* Blue screen messages for exceptions */
void handle_divide_by_zero(){
    cli();
    printf("Divide by zero exception\n");
    sys_halt(HALTNUM);
    sti();

}

void handle_single_step_interrupt(){
    cli();
    printf("Single-step interrupt exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_NMI(){
    cli();
    printf("Non-maskable interrupt exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_breakpoint(){
    cli();
    printf("Breakpoint exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_overflow(){
    cli();
    printf("Overflow exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_bounds(){
    cli();
    printf("Bounds exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_invalid_opcode(){
    cli();
    printf("Invalid opcode exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_coprocessor_not_available(){
    cli();
    printf("Coprocessor not available exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_double_fault(){
    cli();
    printf("Double fault exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_coprocessor_segment_overrun(){
    cli();
    printf("Coprocessor segment overrun\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_invalid_task_state_segment(){
    cli();
    printf("Invalid task state segment exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_segment_not_present(){
    cli();
    printf("Segment not present exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_stack_fault(){
    cli();
    printf("Stack fault exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_general_protection_fault(){
    cli();
    printf("General protection fault exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_page_fault(){
    //cli();
    int32_t faulty_addr = 0;
    asm("movl %%cr2, %0" : "=r" (faulty_addr));
    printf("Page fault exception: %x\n", faulty_addr);
    sys_halt(HALTNUM);

}

void handle_reserved(){
    cli();
    printf("Reserved exception\n");
    sys_halt(HALTNUM);
    sti();

}

void handle_math_fault(){
    cli();
    printf("Math Fault exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_alignment_check(){
    cli();
    printf("Aligment check exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_machine_check(){
    cli();
    printf("Machine check exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_floating_point(){
    cli();
    printf("Floating Point exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_virtualization_exception(){
    cli();
    printf("Virtualization exception\n");
    sys_halt(HALTNUM);
    sti();
}

void handle_control_protection_exception(){
    cli();
    printf("Control protection exception\n");
    sys_halt(HALTNUM);
    sti();
}
// Use this exception for IDT entries between 32 and 256.
void generic_exception(){
    cli();
    printf("Exception\n");
    sys_halt(HALTNUM);
    sti();
}

// Indicate that a keyboard interrupt has occurred. 
void generic_keyboard_interrupt(){
    /* Local variables */
    uint32_t flags; /* Save variable for flags */
    
    cli_and_save(flags);
    
    /* Call the terminal's interrupt method and send keyboard EOI */
    terminal_interrupt();
    send_eoi(KEYBOARD_IRQ);
    
    restore_flags(flags);
}

// Indicate that an RTC interrupt has occurred. 
// Uncomment test_interrupts to prove functionality. 
void generic_RTC_interrupt(){
    /* Local variables */
    uint32_t flags; /* Save variable for flags */
    
    cli_and_save(flags);
    rtc_virtual_interrupt_counter++;

    rtc_interrupt();
   

    /*To virtualize the RTC, set it to the max frequency, but only 
    allow the interrupt to happen at the target frequency */
    /* Call the RTC's interrupt method and send EOI */
    
    send_eoi(RTC_IRQ);
    
    restore_flags(flags);
}

// Indicate that an RTC interrupt has occurred. 
// Uncomment test_interrupts to prove functionality. 
void generic_mouse_interrupt(){
    /* Local variables */
    uint32_t flags; /* Save variable for flags */
    
    cli_and_save(flags);

    mouse_interrupt();
   

    /*To virtualize the RTC, set it to the max frequency, but only 
    allow the interrupt to happen at the target frequency */
    /* Call the RTC's interrupt method and send EOI */
    
    send_eoi(MOUSE_IRQ);
    
    restore_flags(flags);
}

void PIT_interrupt(){
    /* Local variables */
    uint32_t flags; /* Save variable for flags */
    cli_and_save(flags);
    pit_interrupt_counter++;
    schedule();
    send_eoi(0);
    
    restore_flags(flags);
}

// use entry 0x80
void generic_system_call(){
    printf("System call\n");
}
