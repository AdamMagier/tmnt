#ifndef FILE_DRIVERS_H
#define FILE_DRIVERS_H
#define STR_LEN 32
#define DIR_OFFSET 64            //offset from start of boot block to get to directory entries
#define NUM_FILES 64
#define BLOCK_SIZE 4096



typedef struct inode{

    int length;            //length of the data in bytes
    int * data_blocks;    //pointer to the array of data block pointers

}inode_t;


typedef struct d_entry{

    char filename[32];    //32 character filename
    int filetype;        //0  for files giving user-level access to the RTC
                        //1 for the directory
                        //2 for regular files
    int inode_number;

    char padding[24];        //24 bytes reserved


}d_entry_t;


typedef struct boot_block{
    int d_entries_count;
    int inodes_count;
    int data_blocks_count;

    d_entry_t * boot_entries;    //array of directory entries


}boot_block_t;


extern int32_t open_file(const uint8_t* filename);
extern int32_t read_file(int32_t fd, void* buf, int32_t nbytes);
extern int32_t write_file(int32_t fd, const void* buf, int32_t nbytes);
extern int32_t close_file(int32_t fd);
extern int32_t read_file_placeholder(const uint8_t* filename, void *buf, int32_t nbytes, uint32_t offset);

extern int32_t open_directory(const uint8_t* filename);
extern int32_t read_directory(int32_t fd, void* buf, int32_t nbytes);
extern int32_t write_directory(int32_t fd, const void* buf, int32_t nbytes);
extern int32_t close_directory(int32_t fd);
extern int32_t read_directory_placeholder(void *buf);

extern int32_t init_boot_block(boot_block_t * working_block);
extern int32_t read_dentry_by_name(const uint8_t* filename, d_entry_t * fill);
extern int32_t read_dentry_by_index(int index, d_entry_t * fill);
extern int32_t read_data (uint32_t inode_index, uint32_t offset, uint8_t* buf, uint32_t length);
extern void init_file_io();
extern uint8_t * filesys_img;
extern int32_t file_size(const uint8_t* filename);
extern int32_t get_inode(uint32_t inode_number, inode_t * inode_buffer);




//test file functions

extern int32_t launch_file_tests();

extern int32_t iterate_through_directory_test();
extern int32_t copy_entire_file_test();
extern int32_t copy_large_file_test();
extern int32_t copy_from_file_at_offset_test();
extern int32_t copy_end_of_file_test();
extern int32_t read_dentry_by_name_test();
extern int32_t read_dentry_by_index_test();
extern int32_t copy_beginning_of_exe_test();




#endif
