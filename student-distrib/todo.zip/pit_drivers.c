#include "tests.h"
#include "x86_desc.h"
#include "lib.h"
#include "handlers.h"
#include "keyboard.h"
#include "pit_drivers.h"
#include "i8259.h"

// Use PIT instead of RTC because:
// RTC has limited frequency; PIT offers more granularity
// PIT has higher priority interrupts on PIC
// User programs don't interact with the PIT

 
// note_t quarter_G = { .freq = G5, .duration = 2 };

// note_t eighth_G = { .freq = G5, .duration = 1 };

// note_t tied_G = { .freq = G5, .duration = 3 };

// note_t quarter_A = { .freq = A5, .duration = 2 };

// note_t quarter_AF = { .freq = AF5, .duration = 2 };

// note_t eighth_AF = { .freq = AF5, .duration = 1 };

// note_t tied_AF = { .freq = AF5, .duration = 3 };

// note_t eighth_C = { .freq = C5, .duration = 1 };

// note_t quarter_C = { .freq = C5, .duration = 2 };

// note_t quarter_BF = { .freq = BF5 .duration = 2 };

// note_t song[] = {quarter_G, quarter_G, quarter_G, quarter_G, quarter_G, eighth_G, tied_G, quarter_G,
               // quarter_G, quarter_G, quarter_G, quarter_G, quarter_G, eighth_G, tied_G, quarter_G,
               // quarter_A, quarter_A, quarter_A, quarter_A,
               // quarter_AF, eighth_AF, tied_AF, quarter_AF,
               // eighth_C, eighth_C, eighth_C, eighth_C, quarter_BF, quarter_C
// };
int32_t song[SONG_LENGTH][2] = {
    {C_3,  QUARTER}, // 1
    {A_3,  QUARTER}, // 1
    {G_3,  QUARTER}, // 1
    {A_3,  QUARTER}, // 1
    {C_3,  QUARTER}, // 2
    {A_3,  EIGHTH},  // 2
    {G_3,  QUARTER}, // 2
    {G_3,  EIGHTH},  // 2
    {A_3,  QUARTER}, // 2
    {Eb_3, QUARTER}, // 3
    {C_4,  QUARTER}, // 3
    {Bb_3, QUARTER}, // 3
    {C_4,  QUARTER}, // 3
    {Eb_3, QUARTER}, // 4
    {C_4,  EIGHTH},  // 4
    {Bb_3, QUARTER}, // 4
    {Bb_3, EIGHTH},  // 4
    {C_4,  QUARTER}, // 4
    {F_3,  QUARTER}, // 5
    {F_4,  QUARTER}, // 5
    {Eb_4, QUARTER}, // 5
    {F_4,  QUARTER}, // 5
    {Ab_3, QUARTER}, // 6
    {F_4,  EIGHTH},  // 6
    {Eb_4, QUARTER}, // 6
    {Eb_4, EIGHTH},  // 6
    {F_4,  QUARTER}, // 6
    {C_4,  EIGHTH},  // 7
    {C_4,  EIGHTH},  // 7
    {C_4,  EIGHTH},  // 7
    {C_4,  EIGHTH},  // 7
    {Bb_3, QUARTER}, // 7
    {C_4,  TIE_EQ},  // 7
};
/*
 * init_pit
 *      SUMMARY: Initialize the pit to generate 25ms interrupts
 *       INPUTS: none
 *      OUTPUTS: none
 *       RETURN: none
 * SIDE EFFECTS: Sets PIT to square wave mode, channel 0
 */
void init_pit(){
//PIT runs at 1193182 / (loaded value) frequency
//20Hz = 59659.1
//40Hz = 29829.55

// Load the following into Mode/Command Register:
 // Bits         Usage
 // 6 and 7      Select channel :
 //                 0 0 = Channel 0
 //                 0 1 = Channel 1
 //                 1 0 = Channel 2
 //                 1 1 = Read-back command (8254 only)
 // 4 and 5      Access mode :
 //                 0 0 = Latch count value command
 //                 0 1 = Access mode: lobyte only
 //                 1 0 = Access mode: hibyte only
 //                 1 1 = Access mode: lobyte/hibyte
 // 1 to 3       Operating mode :
 //                 0 0 0 = Mode 0 (interrupt on terminal count)
 //                 0 0 1 = Mode 1 (hardware re-triggerable one-shot)
 //                 0 1 0 = Mode 2 (rate generator)
 //                 0 1 1 = Mode 3 (square wave generator)
 //                 1 0 0 = Mode 4 (software triggered strobe)
 //                 1 0 1 = Mode 5 (hardware triggered strobe)
 //                 1 1 0 = Mode 2 (rate generator, same as 010b)
 //                 1 1 1 = Mode 3 (square wave generator, same as 011b)
 // 0            BCD/Binary mode: 0 = 16-bit binary, 1 = four-digit BCD

// Use mode 3 because we're using a constant interval instead of a reload
uint8_t mode_register_val = (CHANNEL << CHANNEL_SHIFT) | (ACCESS_MODE << ACCESS_SHIFT) | (OPERATING_MODE << OPERATING_MODE_SHIFT) | BINARY_MODE;
outb(mode_register_val, MODE_CMD_REGISTER);

//Must write low 8 bits, then high 8 bits of reload value
outb(_40_HZ & LOWMASK, CHANNEL_0_DATAPORT);
outb((_40_HZ & HIGHMASK) >> ONE_BYTE, CHANNEL_0_DATAPORT);

//Channel 0 is connected directly to IRQ0
enable_irq(PIT_IRQ);


}
/* From OSDEV: playsound, nosound, beep */
//Play sound using built in speaker
 static void play_sound(uint32_t nFrequence) {
     uint32_t Div;
     uint8_t tmp;
 
     Div = 1193180 / nFrequence;
     outb(0xb6, 0x43);
     outb((uint8_t) (Div), 0x42);
     outb((uint8_t) (Div >> 8), 0x42);
 
        //And play the sound using the PC speaker
     tmp = inb(0x61);
      if (tmp != (tmp | 3)) {
         outb(tmp | 3, 0x61);
     }
 }
 
 /* From OSDEV: playsound, nosound, beep */
 static void nosound() {
     uint8_t tmp = inb(0x61) & 0xFC;
 
     outb(tmp, 0x61);
 }
 
 /* From OSDEV: playsound, nosound, beep */
 void beep(int freq, int duration) {
     int i;
      play_sound(freq);
      //extremely jank wait/delay
      while (i < 2400000*duration){
          io_wait();
          i++;
      }
      nosound();
      //Short rest to differentiate notes. Experiement
      i = 0;
       while (i < 150000){
          io_wait();
          i++;
      }
 }
 
 void play_turtles(){
     int i;
     for (i = 0; i < SONG_LENGTH; i++){
         beep(song[i][0], song[i][1]);
     }
 }
 

