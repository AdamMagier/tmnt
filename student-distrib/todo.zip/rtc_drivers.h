#ifndef RTC_DRIVERS_H
#define RTC_DRIVERS_H
#define MAX_HZ 1024
#define INITIAL_FREQUENCY 2

extern int32_t rtc_virtual_interrupt_counter;

extern int32_t virtual_frequency;

/* Initialize the frequency to 2Hz. */
extern int32_t open_rtc(const uint8_t* filename);

/* Return after an RTC interrupt has occurred. */
extern int32_t read_rtc(int32_t fd, void* buf, int32_t nbytes);

/* Set the interrupt frequency of the RTC. */
extern int32_t write_rtc(int32_t fd, const void* buf, int32_t nbytes);

/* Close the RTC. Not used except for consistency with syscall device drivers. */
extern int32_t close_rtc(int32_t fd);

#endif
